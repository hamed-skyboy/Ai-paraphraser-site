export default function Paraphraser() {
  return <div><h1>Paraphraser Tool</h1></div>;
}
