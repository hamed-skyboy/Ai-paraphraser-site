export default function BlogExample() {
  return <div><h1>Top 5 Tips to Improve Your Writing with AI Paraphrasers</h1></div>;
}
