export default function VercelGuide() {
  return <div><h1>How to Deploy AI Tools on Vercel (Step-by-Step)</h1></div>;
}
