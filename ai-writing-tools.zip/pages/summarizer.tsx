export default function Summarizer() {
  return <div><h1>Summarizer Tool</h1></div>;
}
