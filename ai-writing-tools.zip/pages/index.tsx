
import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen bg-white dark:bg-gray-900 text-gray-800 dark:text-white p-6">
      <section className="text-center py-12">
        <h1 className="text-4xl font-bold mb-4">AI Writing Assistant Tools</h1>
        <p className="text-lg mb-6">Paraphrase, summarize, and generate titles using AI — fast, accurate, and free.</p>
        <div className="flex justify-center gap-4">
          <Link href="/paraphraser" className="bg-blue-600 text-white px-4 py-2 rounded">Paraphraser</Link>
          <Link href="/summarizer" className="bg-green-600 text-white px-4 py-2 rounded">Summarizer</Link>
          <Link href="/title-generator" className="bg-purple-600 text-white px-4 py-2 rounded">Title Generator</Link>
        </div>
      </section>
    </main>
  );
}
