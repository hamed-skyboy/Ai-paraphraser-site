export default function TitleGenerator() {
  return <div><h1>Title Generator Tool</h1></div>;
}
